
#include <gtk/gtk.h>

void afficher_commentaire(GtkWidget *liste);
