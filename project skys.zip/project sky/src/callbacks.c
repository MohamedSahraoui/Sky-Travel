#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "agent.h"
#include <string.h>
#include "rec.h"
#include "stat.h"
void
on_buttonb3_clicked   (GtkWidget  *objet_graphique, 
			gpointer    user_data)
{
GtkWidget *window2 ;
 GtkWidget *window3;

window2=lookup_widget(objet_graphique,"windowb2");
gtk_widget_hide(window2);
window3 = create_windowb3();
gtk_widget_show (window3);
}



void
on_buttonb4_clicked                  (GtkWidget  *objet_graphique, gpointer user_data)
{
GtkWidget *windowb2, *windowb4;

windowb2=lookup_widget(objet_graphique,"windowb2");
gtk_widget_hide(windowb2);
windowb4 = create_windowb4();
gtk_widget_show (windowb4);

}





//void
//on_buttonb6_clicked      (GtkWidget  *button, gpointer user_data)
//{
//GtkWidget *windowb1, *windowb2;

//windowb2=lookup_widget(button,"windowb2");
//gtk_widget_hide(windowb2);
//windowb1 = create_windowb1();
//gtk_widget_show (windowb1);
//}


void
on_buttonb8_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{

}

void
on_button1_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_buttonb7_clicked                   (GtkWidget     *objet_graphique, gpointer      user_data)
{
agent g;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8;


input1=lookup_widget(objet_graphique,"entryb3");
input2=lookup_widget(objet_graphique,"entryb4");
input3=lookup_widget(objet_graphique,"entryb5");
input4=lookup_widget(objet_graphique,"entryb6");
input5=lookup_widget(objet_graphique,"entry7");
input6=lookup_widget(objet_graphique,"entryb8");
input7=lookup_widget(objet_graphique,"entry8");
input8=lookup_widget(objet_graphique,"entry9");




strcpy(g.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(g.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(g.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(g.num_tel,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(g.mail,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(g.adresse,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(g.identifiant,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(g.mot_pass,gtk_entry_get_text(GTK_ENTRY(input8)));



       
ajouter_agent(g);

}



void
on_buttonb13_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)



{GtkWidget *windowb3;
agent g;
GtkWidget *treeview1;
windowb3=lookup_widget(objet_graphique,"windowb3");
treeview1=lookup_widget(windowb3,"treeviewb1");
afficher_agent(treeview1);
}


//{
//GtkWidget *windowb3;
//GtkWidget *treeview1;
//windowb3=lookup_widget(objet,"windowb3");
//gtk_widget_destroy(windowb3);


//gtk_widget_show(windowb3);

//treeview1=lookup_widget(windowb3,"treeview1");
//afficher_agent(treeview1);

//}




void
on_buttonb9_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
char CIN[20];
int test;
agent g;
GtkWidget *entryb9, *entryb11,*entryb12,*entryb13,*entryb14,*entryb15,*entryb16,*entry10,*entry11;
GtkWidget *windowb3,*windowb6;
GtkWidget *output;
windowb6=create_windowb6();
entryb9=lookup_widget(objet_graphique,"entryb9");
entryb11=lookup_widget(windowb6,"entryb11");
entryb12=lookup_widget(windowb6,"entryb12");
entryb13=lookup_widget(windowb6,"entryb13");
entryb14=lookup_widget(windowb6,"entryb14");
entryb15=lookup_widget(windowb6,"entryb15");
entryb16=lookup_widget(windowb6,"entryb16");
entry11=lookup_widget(windowb6,"entry10");
entry10=lookup_widget(windowb6,"entry11");

output= lookup_widget(objet_graphique,"label1");
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(entryb9)));
if (verifier_cin(CIN)==0)
gtk_label_set_text(GTK_LABEL(output),"agent n'existe pas");
else
{
FILE *f2;
f2=fopen("agent.txt","r"); 
if (f2!=NULL)
{while (fscanf(f2,"%s %s %s %s %s %s %s %s\n",g.nom,g.prenom,g.cin,g.num_tel,g.mail,g.adresse,g.identifiant,g.mot_pass)!=EOF)
{if (strcmp(g.cin,CIN)==0) 
{ gtk_widget_show(windowb6);
gtk_entry_set_text(GTK_ENTRY(entryb11),g.nom) ;
gtk_entry_set_text(GTK_ENTRY(entryb12),g.prenom) ;
gtk_entry_set_text(GTK_ENTRY(entryb13),g.cin) ;
gtk_entry_set_text(GTK_ENTRY(entryb14),g.num_tel) ;
gtk_entry_set_text(GTK_ENTRY(entryb15),g.mail) ;
gtk_entry_set_text(GTK_ENTRY(entryb16),g.adresse) ;
gtk_entry_set_text(GTK_ENTRY(entry10),g.identifiant) ;
gtk_entry_set_text(GTK_ENTRY(entry11),g.mot_pass) ;

break ;}}
}
fclose(f2);
}		// gtk_widget_show(window6);
}
	
/*GtkWidget *windowb3;
		GtkWidget *windowb6;
		windowb3=lookup_widget(objet_graphique,"windowb3");	
		windowb6 = create_windowb6();
		gtk_widget_destroy(windowb3);
		gtk_widget_show(windowb6);*/


/*GtkWidget *input;
GtkWidget *output;
GtkWidget *windowb2, *windowb4;
agent g;
char refer[20];
input=lookup_widget(objet_graphique,"entryb9");
output=lookup_widget(objet_graphique,"label1");
strcpy(refer,gtk_entry_get_text(GTK_ENTRY(input)));
if(strcmp(refer,g.cin)==0)
gtk_label_set_text(GTK_LABEL(output),"client n'existe pas");
else
{
modifier_agent(refer);
gtk_label_set_text(GTK_LABEL(output),"suppression avec succée");
windowb4=lookup_widget(objet_graphique,"windowb6");

windowb2=lookup_widget(objet_graphique,"windowb3");
gtk_widget_hide(windowb2);
windowb4 = create_windowb4();
gtk_widget_show (windowb4);
}*/







void
on_buttonb14_clicked                   (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
agent g;
GtkWidget *entryb9,*entryb12,*entryb13,*entryb14,*entryb15,*entryb16,*entry10,*entry11;
GtkWidget *output;
entryb9=lookup_widget(objet_graphique,"entryb11");
entryb12=lookup_widget(objet_graphique,"entryb12");
entryb13=lookup_widget(objet_graphique,"entryb13");
entryb14=lookup_widget(objet_graphique,"entryb14");
entryb15=lookup_widget(objet_graphique,"entryb15");
entryb16=lookup_widget(objet_graphique,"entryb16");
entry10=lookup_widget(objet_graphique,"entry10");
entry11=lookup_widget(objet_graphique,"entry11");
output=lookup_widget(objet_graphique,"label2");
strcpy(g.nom,gtk_entry_get_text(GTK_ENTRY(entryb9)));
strcpy(g.prenom,gtk_entry_get_text(GTK_ENTRY(entryb12)));
strcpy(g.cin,gtk_entry_get_text(GTK_ENTRY(entryb13)));
strcpy(g.num_tel,gtk_entry_get_text(GTK_ENTRY(entryb14)));
strcpy(g.mail,gtk_entry_get_text(GTK_ENTRY(entryb15)));
strcpy(g.adresse,gtk_entry_get_text(GTK_ENTRY(entryb16)));
strcpy(g.identifiant,gtk_entry_get_text(GTK_ENTRY(entry10)));
strcpy(g.mot_pass,gtk_entry_get_text(GTK_ENTRY(entry11)));

modifier_agent(g);
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés") ;
}





void
on_buttonb10_clicked                (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *output;
agent g;
char ref[20];
input=lookup_widget(objet_graphique,"entryb10");
output=lookup_widget(objet_graphique,"labelb29");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input)));
if(strcmp(ref,g.cin)==0)
gtk_label_set_text(GTK_LABEL(output),"client n'existe pas");
else
{
supprimer_agent(ref);
gtk_label_set_text(GTK_LABEL(output),"suppression avec succée");
}
}
/*GtkWidget *windowb3;
	GtkWidget *window4;
windowb3 = 
	windowb3=lookup_widget(objet_graphique,"windowb3");	
	

}
*/





void
on_buttonb5_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *windowb2, *windowb5;
windowb2=lookup_widget(objet_graphique,"windowb2");
gtk_widget_hide(windowb2);
windowb5 = create_windowb5();
gtk_widget_show (windowb5);
}
void
on_buttonbackb2_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *windowb3, *windowb2;
windowb3=lookup_widget(objet_graphique,"windowb3");
gtk_widget_hide(windowb3);
windowb2 = create_windowb2();
gtk_widget_show (windowb2);
}
void
on_buttonbackb3_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *windowb3, *windowb2;
windowb3=lookup_widget(objet_graphique,"windowb3");
gtk_widget_hide(windowb3);
windowb2 = create_windowb2();
gtk_widget_show (windowb2);
}
void
on_buttonback5_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *windowb5, *windowb2;
windowb5=lookup_widget(objet_graphique,"windowb5");
gtk_widget_hide(windowb5);
windowb2 = create_windowb2();
gtk_widget_show (windowb2);
}


void
on_buttonb555_clicked              (GtkWidget      *objet_graphique,
                                        gpointer         user_data)



{GtkWidget *windowb5;

GtkWidget *treeview;
windowb5=lookup_widget(objet_graphique,"windowb5");
treeview=lookup_widget(windowb5,"treeviewb3");
afficher_stat(treeview);
}

void
on_buttonback4_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *windowb2, *windowb5;
windowb5=lookup_widget(objet_graphique,"windowb5");
gtk_widget_hide(windowb5);
windowb2 = create_windowb2();
gtk_widget_show (windowb2);
}

void
on_buttonb11_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)

{GtkWidget *windowb4;

GtkWidget *treeviewb;
windowb4=lookup_widget(objet_graphique,"windowb4");
treeviewb=lookup_widget(windowb4,"treeviewb2");
afficher_commentaire(treeviewb);
}


void
on_buttonb963_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
{
GtkWidget *windowb3, *windowb6;
windowb6=lookup_widget(button,"windowb6");
gtk_widget_hide(windowb6);
windowb3 = create_windowb3();
gtk_widget_show (windowb3);
}
}

