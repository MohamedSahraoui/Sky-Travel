#include <gtk/gtk.h>
typedef struct 
{
char nom[25];
char prenom[35];
char cin[20];
char num_tel[20];
char mail[35];
char adresse[60];
char identifiant[60];
char mot_pass[60];
}agent;
void ajouter_agent(agent g);
void afficher_agent(GtkWidget *liste);
int supprimer_agent(char refer[]);
int modifier_agent(agent g);
int verifier_cin(char CIN[]);
