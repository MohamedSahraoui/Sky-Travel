#include <gtk/gtk.h>


void
on_buttonb3_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb4_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button1_clicked                   (GtkButton       *objet_graphique,
                                        gpointer         user_data);


void
on_buttonb8_clicked                    (GtkButton      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb7_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb13_clicked                    (GtkButton     *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb9_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb14_clicked                   (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb10_clicked                       (GtkButton      *objet_graphique,
                                        gpointer         user_data);




void
on_buttonb5_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonbackb2_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data);


void
on_buttonbackb3_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonback5_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb555_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonback4_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb11_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonb963_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
