
#include <gtk/gtk.h>


void afficher_stat(GtkWidget *liste);
