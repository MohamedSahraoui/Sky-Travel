



#include<stdio.h>
#include<string.h>
#include "agent.h"
#include <gtk/gtk.h>


enum
{

     NOM,
     PRENOM,
     CIN,
     NUM_TEL,
     MAIL,
     ADRESSE,
     ID,
     MP,
     COLUMNS
};


void ajouter_agent(agent g)
{

FILE *f,*f1;
f=fopen("agent.txt","a+");
f1=fopen("users.txt","a+");
if((f!=NULL)&&(f1!=NULL))
{
fprintf(f,"%s %s %s %s %s %s %s %s \n",g.nom,g.prenom,g.cin,g.num_tel,g.mail,g.adresse,g.identifiant,g.mot_pass);
fprintf(f1,"%s %s 1\n",g.identifiant,g.mot_pass);
}
fclose(f1);
fclose(f);
}



void afficher_agent(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char nom[25];
char prenom[35];
char cin[20];
char num_tel[20];
char mail[35];
char adresse[60];
char identifiant[60];
char mot_pass[60];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" num_tel",renderer, "text",NUM_TEL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" mail",renderer,"text",MAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" adresse",renderer, "text",ADRESSE,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" identifiant",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" mot_pass",renderer, "text",MP,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	

}
	store=gtk_list_store_new(8,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("agent.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("agent.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s %s %s\n",nom,prenom,cin,num_tel,mail,adresse,identifiant,mot_pass)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,CIN,cin,NUM_TEL,num_tel,MAIL,mail,ADRESSE,adresse,ID,identifiant,MP,mot_pass-1);
	}
	fclose(f);}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

	
}



int supprimer_agent(char refer[])
{
FILE *f,*f1;
agent g;
 
f=fopen("agent.txt","r"); 
f1=fopen("agent_tmp.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",g.nom,g.prenom,g.cin,g.num_tel,g.mail,g.adresse,g.identifiant,g.mot_pass)!=EOF) 
{
if(strcmp(refer,g.cin)!=0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s\n",g.nom,g.prenom,g.cin,g.num_tel,g.mail,g.adresse,g.identifiant,g.mot_pass);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("agent.txt","w"); 
f1=fopen("agent_tmp.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s %s %s %s\n",g.nom,g.prenom,g.cin,g.num_tel,g.mail,g.adresse,g.identifiant,g.mot_pass)!=EOF) 
{
if(strcmp(refer,g.cin)!=0)
{
fprintf(f,"%s %s %s %s %s %s %s %s\n",g.nom,g.prenom,g.cin,g.num_tel,g.mail,g.adresse,g.identifiant,g.mot_pass);
}}
fclose(f) ; 
fclose(f1);
}}

int modifier_agent(agent g)
{

agent m;

FILE *f;
FILE *f2;
f=fopen("agent.txt","r");
f2=fopen("agent_tmp.txt","a+"); 
if (f!=NULL)
{
if (f2!=NULL)

{ 
     while (fscanf(f,"%s %s %s %s %s %s %s %s\n",m.nom,m.prenom,m.cin,m.num_tel,m.mail,m.adresse,m.identifiant,m.mot_pass)!=EOF)
    { 
	if (strcmp(g.cin,m.cin)==0){
   fprintf(f2,"%s %s %s %s %s %s %s %s\n",g.nom,g.prenom,g.cin,g.num_tel,g.mail,g.adresse,g.identifiant,g.mot_pass);
}
	else 	
{	    fprintf(f2,"%s %s %s %s %s %s %s %s\n",m.nom,m.prenom,m.cin,m.num_tel,m.mail,m.adresse,m.identifiant,m.mot_pass);
     }

}}
fclose(f2);
fclose(f);
remove("agent.txt");
rename("agent_tmp.txt","agent.txt");

}
 

}


int verifier_cin(char CIN[])
{agent g;
FILE *f;
int test = 0 ; 
f=fopen("agent.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",g.nom,g.prenom,g.cin,g.num_tel,g.mail,g.adresse,g.identifiant,g.mot_pass)!=EOF) 
{ 
if((strcmp(g.cin,CIN)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}
