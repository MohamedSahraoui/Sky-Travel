#include <gtk/gtk.h>


void
on_buttonB1_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonA1_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonA3_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_checkbuttonA2_toggled                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

gboolean
on_checkbuttonA1_toggled                (GtkWidget        *objet_graphique,
                                        gpointer         user_data);



void
on_buttonB2_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonB3_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonB4_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonC1_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_buttonX1_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAAA_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
