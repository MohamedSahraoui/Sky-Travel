#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include "fct_divers.h"
#include<ctype.h>

#include <gtk/gtk.h>



//////////////////Fonction-de-vérification////////////////////////////

int verifier (char login[], char password[])
{
FILE *f ;
char l[20],p[20];
int test=0;
f=fopen("/home/hamdi/project1000/src/client.txt","r") ;
if (f!=NULL) {
while (fscanf(f,"%s %s \n",l,p)!=EOF) {
if ((!strcmp(l,login)) &&(!strcmp(p,password))){
test=0;
break;
}}


return test ;}
}


///////////////////////////Ajout-de-client-Hamza//////////////////////////////////

void ajouter_client (cll A)

{
   FILE*f ;
   
   f=fopen("/home/hamdi/projet1000/src/client.txt","a+");
   
    if(f!=NULL)
   {
     char username[30]="\0";
     strcpy(username, A.nom);
     strcat(username, A.prenom);
      
     fprintf(f, "%s %s %s %s %s %s %d/%d/%d %s %s \n", username, A.nom, A.prenom, A.sexe, A.cin, A.tel, A.jj,A.mm,A.yy, A.mail, A.passwd);
     
   }
   
   fclose(f);
   
}


///////////////////Ajout-réservation-Hamza////////////////////////////////////////////

void ajouter_reserv (client C , char hotel[], char heb[], char vol[], char voiture[],int jd ,int md ,int yd ,int jj ,int mj ,int yj)

{
   FILE*f ;
   
   f=fopen("/home/hamdi/projet1000/src/reservation.txt","a+");
   
    if(f!=NULL)
   {
     char code[30]="sky-sky";
     strcat(code, C.nom);
     strcat(code, C.prenom); 
     fprintf(f, "%s %s %s %s %s %s %s %d/%d/%d %d/%d/%d \n", code, C.nom, C.prenom, hotel, heb, vol, voiture,jd,md,yd,jj,mj,yj);
     
   }
   
   fclose(f);
   
}

/////////////////////modifier-reservation-Hamza/////////////////////////////

void modifier_reservation(char test[],char heb1[] ,char voiture1[] ,char vol1[] ,char hotel1[],int jd ,int md ,int yd ,int jj ,int mj ,int yj )
{
FILE *f;
   FILE *f1 ; 

  char code[50]; 
  char nom[50]; 
  char prenom[50];
  char hotel[50];  
  char heb[50]; 
  char vol[50]; 
  char voiture[50]; 
  char debut[50]; 
  char fin[50]; 

int r ; 

    f=fopen("/home/hamdi/projet1000/src/reservation.txt","r") ; 
    f1=fopen("/home/hamdi/projet1000/src/reservation1.txt","w");
     if (f!=NULL) 
           { 
                if (f1!=NULL) 
                    { 
     while (fscanf(f,"%s %s %s %s %s %s %s %s %s \n",code, nom, prenom, hotel, heb, vol, voiture, debut, fin)!=EOF)
           { 
              if(strcmp(test,code)!=0)
                    {
                   fprintf(f1,"%s %s %s %s %s %s %s %s %s \n",code, nom, prenom, hotel, heb, vol, voiture, debut, fin) ;
                      
                    }
             else { fprintf(f1,"%s %s %s %s %s %s %s %d/%d/%d %d/%d/%d \n",code, nom, prenom, hotel1, heb1, vol1, voiture1, jd, md, yd, jj, mj, yj);
 r=1 ; 
}
           }
                    }fclose(f1) ; 
           }fclose(f); 
if (r) 
     {
        remove("/home/hamdi/projet1000/src/reservation.txt") ; 
        rename("/home/hamdi/projet1000/src/reservation1.txt","/home/hamdi/projet1000/src/reservation.txt") ; 
     }               
 }   




///////////////////supprimer-resrvation-Hamza//////////////////////////

void supprimer_reserv(char test[])
{

   FILE *f;
   FILE *f1 ; 

  char code[50]; 
  char nom[50]; 
  char prenom[50];
  char hotel[50];  
  char heb[50]; 
  char vol[50]; 
  char voiture[50]; 
  char debut[50]; 
  char fin[50]; 

int r ; 

    f=fopen("/home/hamdi/projet1000/src/reservation.txt","r") ; 
    f1=fopen("/home/hamdi/projet1000/src/reservation1.txt","w");
     if (f!=NULL) 
           { 
                if (f1!=NULL) 
                    { 
     while (fscanf(f,"%s %s %s %s %s %s %s %s %s \n",code, nom, prenom, hotel, heb, vol, voiture, debut, fin)!=EOF)
           { 
              if(strcmp(test,code)!=0)
                    {
                      fprintf(f1,"%s %s %s %s %s %s %s %s %s \n",code, nom, prenom, hotel, heb, vol, voiture, debut, fin) ;
                       r=1 ; 
                    }
           }
                    }fclose(f1) ; 
           }fclose(f); 
if (r) 
     {
        remove("/home/hamdi/projet1000/src/reservation.txt") ; 
        rename("/home/hamdi/projet1000/src/reservation1.txt","/home/hamdi/projet1000/src/reservation.txt") ; 
     }               
 }   



 

///////////////////////Affichage-Hamza/////////////////////////////////////


enum
{

code, nom, prenom, hotel, heb, vol, voiture, debut, fin,

	COLUMNS
};



void afficher_reservation(GtkWidget *treeview)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	 char ch1[50],ch2[50],ch3[50],ch4[50],ch5[50],ch6[50],ch7[50],ch8[50],ch9[50]; 
 	 
	FILE *f;
	

	store=NULL;
	
	store=gtk_tree_view_get_model(treeview);	
	if (store==NULL)
	{

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("code", renderer,"text",code, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",nom, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
                

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",prenom, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
			

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("hotel", renderer, "text",hotel, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("excursion", renderer, "text",heb, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("vol", renderer, "text",vol, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("voiture", renderer, "text",voiture, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

        	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("date debut", renderer, "text",debut, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

        	renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("date fin", renderer, "text",fin, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);


	
		
		

	}
		store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING , G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f = fopen("/home/hamdi/projet1000/src/reservation.txt", "r");
	
	if(f ==NULL)
	{

		return;
	}		
	else
	{
	
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,ch6,ch7,ch8,ch9)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter,code,ch1,nom,ch2,prenom,ch3,hotel,ch4,heb,ch5,vol,ch6,voiture,ch7,debut,ch8,fin,ch9,-1);
		}
		
		fclose(f);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
	
}









