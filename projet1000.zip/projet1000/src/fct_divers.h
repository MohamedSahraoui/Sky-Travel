#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<ctype.h>

#include <gtk/gtk.h>

typedef struct 
	{
	       char nom[20]; 
               char prenom[20];
               char cin[20] ;
               char tel[20];
               char mail[20];
               char passwd[20];
               int jj ; 
               int  mm ; 
                int  yy ; 
               char sexe[20];
	}cll;


typedef struct 
    {
	    char nom[20],  prenom[20], username[20], password[20];
    }client;


int estnombre (const char *c);
int date (const char *d);
int comparer (char mdp[], char cmdp[]);
int verifier (char login[], char password[]);
void ajouter_client (cll A);
void ajouter_reserv (client C , char hotel[], char heb[], char vol[], char voiture[],int jd ,int md ,int yd ,int jj ,int mj ,int yj);
void modifier_reservation(char test[],char heb[] ,char voiture[] ,char vol[] ,char hotel[],int jd ,int md ,int yd ,int jj ,int mj ,int yj )
;
void supprimer_reserv (char test[]);
void afficher_reservation(GtkWidget *treeview) ;
