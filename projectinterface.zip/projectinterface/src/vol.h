#include <gtk/gtk.h>

struct vols
{
  gchar numero[20];
  gchar date_depart[20];
  gchar lieu_depart[20];
  gchar date_arrive[20];
  gchar lieu_arrive[20];
  gchar aeroport[20];
} ;

typedef struct vols vol;
vol v;
struct location
{
  gchar numero[20];
  gchar debut_location[20];
  gchar lieu[20];
  gchar fin_location[20];
  gchar marque[20];
  gchar prix[20];
} ;

typedef struct location location ;
struct hebergements
{
  gchar numero[20];
  gchar date_depart[20];
  gchar date_arrive[20];
  gchar nombre_chambres[20];
  gchar nombre_chambres_double[20];
  gchar prix[20];
} ;

typedef struct hebergements hebergements ;
void ajouter_vol(vol v);
void afficher_vols(GtkWidget *liste);
void afficher_excursions(GtkWidget *liste);
void afficher_locations(GtkWidget *liste);
void afficher_vols_reserve(GtkWidget *liste);
void afficher_heb_reserve(GtkWidget *liste);
void afficher_heb(GtkWidget *liste);
void afficher_locations_reserve(GtkWidget *liste);
void afficher_excursions_reserve(GtkWidget *liste);
void cell_edited (GtkCellRendererText *renderer,gchar *path, gchar* newtext, GtkListStore *store);
