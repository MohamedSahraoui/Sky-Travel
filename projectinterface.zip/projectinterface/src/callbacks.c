#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "vol.h"


void
on_envoyer_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_btn_reservation_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
  reservation = create_reservation ();
  gtk_widget_show(reservation);
  gtk_widget_hide(espace_client);
}


void
on_btn_reclamation_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
  ecrire_une_reclamation = create_ecrire_une_reclamation ();
  gtk_widget_show(ecrire_une_reclamation);
  gtk_widget_hide(espace_client);
}

void
on_avis_clicked                        (GtkWidget       *button,
                                        gpointer         user_data)
{
  avis = create_avis ();
  gtk_widget_show(avis);
  gtk_widget_hide(espace_client);
}

void
on_btn_vol_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
  gestion_des_vols = create_gestion_des_vols ();
  GtkWidget* tree=lookup_widget(gestion_des_vols,"treeview1");
   afficher_vols(tree);
  gtk_widget_show(gestion_des_vols);
  gtk_widget_hide(reservation);
}


void
on_gestion_des_hebergements_clicked   (GtkWidget       *button,
                                        gpointer         user_data)
{
  gestion_des_hebergements = create_gestion_des_hebergements_ ();
  GtkWidget* tree=lookup_widget(gestion_des_hebergements,"treeview2");
   afficher_heb(tree);
  gtk_widget_show(gestion_des_hebergements);
  gtk_widget_hide(reservation);
}


void
on_btn_excursions_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
  gestion_des_excursions = create_gestion_des_excursions ();
  afficher_excursions(lookup_widget(gestion_des_excursions,"treeview3"));
  gtk_widget_show(gestion_des_excursions);
  gtk_widget_hide(reservation);
}


void
on_btn_location_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
  gestion_des_locations_des_voitures = create_gestion_des_locations_des_voitures ();
  afficher_locations(lookup_widget(gestion_des_locations_des_voitures,"treeview4"));
  gtk_widget_show(gestion_des_locations_des_voitures);
  gtk_widget_hide(reservation);
}

void
on_valider_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{ char a[20] ;  int n;
  FILE* f;
GtkWidget* combo;
GtkWidget* spin;
combo = lookup_widget(avis,"combobox1");
spin= lookup_widget(avis,"spinbutton1");
strcpy(a,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo)));
n=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));
  f=fopen("avis.txt","a+");
  fprintf(f, "AVIS: %s , Note: %d\n",a,n );
  fclose(f);
  gtk_widget_show(espace_client);
  gtk_widget_hide(avis);

}

void
on_btn_panier_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
panier=create_panier();
afficher_vols_reserve(lookup_widget(panier,"treeview8"));
afficher_heb_reserve(lookup_widget(panier,"treeview7"));
afficher_excursions_reserve(lookup_widget(panier,"treeview6"));
afficher_locations_reserve(lookup_widget(panier,"treeview5"));
gtk_widget_show(panier);
gtk_widget_hide(reservation);
}


void
on_ajouter_vol_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkTreeSelection *selection;
          GtkTreeModel     *model;
          GtkTreeIter iter;
          GtkWidget* p;
          gchar *numero,*date_depart,*lieu_depart,*date_arrive,*lieu_arrive,*aeroport;


          FILE* f=fopen("vols_res.txt","a+");
          p=lookup_widget(button,"treeview1");
          selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
          if (gtk_tree_selection_get_selected(selection, &model, &iter))
          {  gtk_tree_model_get (model,&iter,0,&numero,1,&date_depart,2,&lieu_depart,3,&date_arrive,4,&lieu_arrive,5,&aeroport,-1);
             fprintf(f,"%s %s %s %s %s %s\n",numero,date_depart,lieu_depart,date_arrive,lieu_arrive,aeroport);
             gtk_list_store_remove(GTK_LIST_STORE(model),&iter);}
          fclose(f);


          gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label34")),"Vol Ajouté!");
}

void
on_ajouter_hebergement_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkTreeSelection *selection;
          GtkTreeModel     *model;
          GtkTreeIter iter;
          GtkWidget* p;
          gchar *numero,*date_depart,*date_arrive,*nombre_chambres,*nombre_chambres_double,*prix;


          FILE* f=fopen("hebergements_res.txt","a+");
          p=lookup_widget(button,"treeview2");
          selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
          if (gtk_tree_selection_get_selected(selection, &model, &iter))
          {  gtk_tree_model_get (model,&iter,0,&numero,1,&date_depart,2,&date_arrive,3,&nombre_chambres,4,&nombre_chambres_double,5,&prix,-1);
             fprintf(f,"%s %s %s %s %s %s\n",numero,date_depart,date_arrive,nombre_chambres,nombre_chambres_double,prix);
             gtk_list_store_remove(GTK_LIST_STORE(model),&iter);}
          fclose(f);


          gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label35")),"Hotel Ajouté!");
}


void
on_ajouter_excursion_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkTreeSelection *selection;
          GtkTreeModel     *model;
          GtkTreeIter iter;
          GtkWidget* p;
          gchar *numero,*date_depart,*date_arrive,*lieu_depart,*lieu_arrive,*prix,*programme;


          FILE* f=fopen("excursion_reserve.txt","a+");
          p=lookup_widget(button,"treeview3");
          selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
          if (gtk_tree_selection_get_selected(selection, &model, &iter))
          {  gtk_tree_model_get (model,&iter,0,&numero,1,&date_depart,2,&date_arrive,3,&lieu_depart,4,&lieu_arrive,5,&prix,6,&programme,-1);
             fprintf(f,"%s %s %s %s %s %s %s\n",numero,date_depart,date_arrive,lieu_depart,lieu_arrive,prix,programme);
             gtk_list_store_remove(GTK_LIST_STORE(model),&iter);}
          fclose(f);


          gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label36")),"Excursion Ajouté!");

}


void
on_ajouter_location_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkTreeSelection *selection;
          GtkTreeModel     *model;
          GtkTreeIter iter;
          GtkWidget* p;
          gchar *numero,*debut_location,*lieu,*fin_location,*marque,*prix;


          FILE* f=fopen("locations_reserve.txt","a+");
          p=lookup_widget(button,"treeview4");
          selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
          if (gtk_tree_selection_get_selected(selection, &model, &iter))
          {  gtk_tree_model_get (model,&iter,0,&numero,1,&debut_location,2,&lieu,3,&fin_location,4,&marque,5,&prix,-1);
             fprintf(f,"%s %s %s %s %s %s\n",numero,debut_location,lieu,fin_location,marque,prix
);
             gtk_list_store_remove(GTK_LIST_STORE(model),&iter);}
          fclose(f);


          gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label37")),"Location Ajouté!");

}


void
on_supp_vol_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
          GtkTreeSelection *selection;
          GtkTreeModel     *model;
          GtkTreeIter iter;
          GtkWidget* p;
          gchar *numero,*date_depart,*lieu_depart,*date_arrive,*lieu_arrive,*aeroport;
          p=lookup_widget(button,"treeview8");
          selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
          if (gtk_tree_selection_get_selected(selection, &model, &iter))
          { FILE*  f=fopen("vols_res.txt","w+");
              gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
            gboolean  valid=gtk_tree_model_get_iter_first(model,&iter);
              while ( valid)
              {
                gtk_tree_model_get (model,&iter,0,&numero,1,&date_depart,2,&lieu_depart,3,&date_arrive,4,&lieu_arrive,5,&aeroport,-1);
                fprintf(f,"%s %s %s %s %s %s\n",numero,date_depart,lieu_depart,date_arrive,lieu_arrive,aeroport);

                  valid=gtk_tree_model_iter_next (model,&iter);
              }fclose(f);}

          gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label39")),"Vol Supprimé!");

}


void
on_supp_hebergement_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
          GtkTreeSelection *selection;
          GtkTreeModel     *model;
          GtkTreeIter iter;
          GtkWidget* p;
          gchar *numero,*date_depart,*date_arrive,*nombre_chambres,*nombre_chambres_double,*prix;
          p=lookup_widget(button,"treeview7");
          selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
          if (gtk_tree_selection_get_selected(selection, &model, &iter))
          {  FILE* f=fopen("hebergements_res.txt","w+");
              gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
            gboolean  valid=gtk_tree_model_get_iter_first(model,&iter);
              while ( valid)
              {
                gtk_tree_model_get (model,&iter,0,&numero,1,&date_depart,2,&date_arrive,3,&nombre_chambres,4,&nombre_chambres_double,5,&prix,-1);
                   fprintf(f,"%s %s %s %s %s %s\n",numero,date_depart,date_arrive,nombre_chambres,nombre_chambres_double,prix);

                  valid=gtk_tree_model_iter_next (model,&iter);
              }fclose(f);}

          gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label40")),"Hotel Supprimé!");
}


void
on_supp_excursion_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
          GtkTreeSelection *selection;
          GtkTreeModel     *model;
          GtkTreeIter iter;
          GtkWidget* p;
          gchar *numero,*date_depart,*date_arrive,*lieu_depart,*lieu_arrive,*prix,*programme;
          p=lookup_widget(button,"treeview6");
          selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
          if (gtk_tree_selection_get_selected(selection, &model, &iter))
          { FILE*  f=fopen("excursion_reserve.txt","w+");
              gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
            gboolean  valid=gtk_tree_model_get_iter_first(model,&iter);
              while ( valid)
              {
                gtk_tree_model_get (model,&iter,0,&numero,1,&date_depart,2,&date_arrive,3,&lieu_depart,4,&lieu_arrive,5,&prix,6,&programme,-1);
                   fprintf(f,"%s %s %s %s %s %s %s\n",numero,date_depart,date_arrive,lieu_depart,lieu_arrive,prix,programme);
                    valid=gtk_tree_model_iter_next (model,&iter);
              }fclose(f);}

          gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label41")),"Excursion Supprimé!");
}


void
on_supp_location_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
          GtkTreeSelection *selection;
          GtkTreeModel     *model;
          GtkTreeIter iter;
          GtkWidget* p;
          gchar *numero,*debut_location,*lieu,*fin_location,*marque,*prix;

          p=lookup_widget(button,"treeview5");
          selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
          if (gtk_tree_selection_get_selected(selection, &model, &iter))
          { FILE*  f=fopen("locations_reserve.txt","w+");
              gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
          gboolean    valid=gtk_tree_model_get_iter_first(model,&iter);
              while ( valid)
              {
                gtk_tree_model_get (model,&iter,0,&numero,1,&debut_location,2,&lieu,3,&fin_location,4,&marque,5,&prix,-1);
                   fprintf(f,"%s %s %s %s %s %s\n",numero,debut_location,lieu,fin_location,marque,prix
      );
                  valid=gtk_tree_model_iter_next (model,&iter);
              }fclose(f);}

          gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label38")),"Location Supprimé!");
}


void
on_modifier_vol_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkTreeSelection *selection;
  GtkTreeModel     *model;
  GtkTreeIter iter;
  GtkWidget* p;
  gchar *numero,*date_depart,*lieu_depart,*date_arrive,*lieu_arrive,*aeroport;
  p=lookup_widget(button,"treeview8");
  selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
  if (gtk_tree_selection_get_selected(selection, &model, &iter))
  { FILE*  f=fopen("vols_res.txt","w+");

    gboolean  valid=gtk_tree_model_get_iter_first(model,&iter);
      while ( valid)
      {
        gtk_tree_model_get (model,&iter,0,&numero,1,&date_depart,2,&lieu_depart,3,&date_arrive,4,&lieu_arrive,5,&aeroport,-1);
        fprintf(f,"%s %s %s %s %s %s\n",numero,date_depart,lieu_depart,date_arrive,lieu_arrive,aeroport);

          valid=gtk_tree_model_iter_next (model,&iter);
      }fclose(f);}

  gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label39")),"Vol Modifié!");
}


void
on_modifier_hebergement_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkTreeSelection *selection;
  GtkTreeModel     *model;
  GtkTreeIter iter;
  GtkWidget* p;
    gchar *numero,*date_depart,*date_arrive,*nombre_chambres,*nombre_chambres_double,*prix;
  p=lookup_widget(button,"treeview7");
  selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
  if (gtk_tree_selection_get_selected(selection, &model, &iter))
  { FILE*  f=fopen("hebergements_res.txt","w+");

  gboolean    valid=gtk_tree_model_get_iter_first(model,&iter);
      while ( valid)
      {
        gtk_tree_model_get (model,&iter,0,&numero,1,&date_depart,2,&date_arrive,3,&nombre_chambres,4,&nombre_chambres_double,5,&prix,-1);
           fprintf(f,"%s %s %s %s %s %s\n",numero,date_depart,date_arrive,nombre_chambres,nombre_chambres_double,prix);

          valid=gtk_tree_model_iter_next (model,&iter);
      }fclose(f);}

  gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label40")),"Hotel Modifié!");

}


void
on_modifier_excursion_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkTreeSelection *selection;
  GtkTreeModel     *model;
  GtkTreeIter iter;
  GtkWidget* p;
  gchar *numero,*date_depart,*date_arrive,*lieu_depart,*lieu_arrive,*prix,*programme;
  p=lookup_widget(button,"treeview6");
  selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
  if (gtk_tree_selection_get_selected(selection, &model, &iter))
  {  FILE* f=fopen("excursion_reserve.txt","w+");

    gboolean  valid=gtk_tree_model_get_iter_first(model,&iter);
      while ( valid)
      {
        gtk_tree_model_get (model,&iter,0,&numero,1,&date_depart,2,&date_arrive,3,&lieu_depart,4,&lieu_arrive,5,&prix,6,&programme,-1);
           fprintf(f,"%s %s %s %s %s %s %s\n",numero,date_depart,date_arrive,lieu_depart,lieu_arrive,prix,programme);
            valid=gtk_tree_model_iter_next (model,&iter);
      }fclose(f);}

  gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label41")),"Excursion Modifié!");

}


void
on_modifier_location_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkTreeSelection *selection;
  GtkTreeModel     *model;
  GtkTreeIter iter;
  GtkWidget* p;
    gchar *numero,*debut_location,*lieu,*fin_location,*marque,*prix;
  p=lookup_widget(button,"treeview5");
  selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
  if (gtk_tree_selection_get_selected(selection, &model, &iter))
  {  FILE* f=fopen("locations_reserve.txt","w+");

    gboolean  valid=gtk_tree_model_get_iter_first(model,&iter);
      while ( valid)
      {
        gtk_tree_model_get (model,&iter,0,&numero,1,&debut_location,2,&lieu,3,&fin_location,4,&marque,5,&prix,-1);
           fprintf(f,"%s %s %s %s %s %s\n",numero,debut_location,lieu,fin_location,marque,prix
);
          valid=gtk_tree_model_iter_next (model,&iter);
      } fclose(f);
    }

  gtk_label_set_text(GTK_LABEL(lookup_widget(button,"label38")),"Location Modifié!");

}
