#include <gtk/gtk.h>


struct excursion
{
  gchar numero[20];
  gchar date_depart[20];
  gchar date_arrive[20];
  gchar lieu_depart[20];
  gchar lieu_arrive[20];
  gchar prix[20];
  gchar programme[20];
} ;

typedef struct excursion excursion ;
GtkWidget *gestion_des_vols ,*gestion_des_hebergements,
*gestion_des_excursions,*gestion_des_locations_des_voitures,*espace_client,
*reservation,*avis,*gestion_des_reclamations,*ecrire_une_reclamation,*panier;

void
on_envoyer_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_btn_reservation_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_btn_reclamation_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_avis_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_btn_vol_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);



void
on_btn_excursions_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_btn_location_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_gestion_des_hebergements_clicked    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_btn_panier_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouter_vol_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouter_hebergement_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouter_excursion_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouter_location_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supp_vol_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supp_hebergement_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supp_excursion_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supp_location_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_vol_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_hebergement_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_excursion_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_location_clicked           (GtkWidget       *button,
                                        gpointer         user_data);
