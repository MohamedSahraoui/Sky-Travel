#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif



#include "support.h"



#include <stdlib.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include "interface.h"
#include "callbacks.h"
#include "vol.h"


void afficher_vols(GtkWidget *liste)
{
  enum {
          numero,date_depart,lieu_depart,date_arrive,lieu_arrive,aeroport

  };
GtkListStore *store=NULL;
GtkTreeViewColumn *column;
GtkCellRenderer *cell;
FILE *f;



/* Creation du modele */
        store = gtk_list_store_new(6,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
/* Insertion des elements */
      f=fopen("vols.txt","a+");
        while(fscanf(f,"%s %s %s %s %s %s\n",v.numero,v.date_depart,v.lieu_depart,v.date_arrive,v.lieu_arrive,v.aeroport)!=EOF)
        {GtkTreeIter pIter;
  /* Creation de la nouvelle ligne */
        gtk_list_store_append(store, &pIter);
  /* Mise a jour des donnees */
        gtk_list_store_set(store, &pIter,

                           numero,v.numero,
                           date_depart,v.date_depart,
                           lieu_depart,v.lieu_depart,
                           date_arrive,v.date_arrive,
                           lieu_arrive,v.lieu_arrive,
                           aeroport,v.aeroport,
                            -1);}
        fclose(f);


  /* Creation de la 2eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Numero Vol",
                                                            cell,
                                                            "text", numero,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

  /* Creation de la 3eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date Depart",
                                                            cell,
                                                            "text", date_depart,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 4eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Lieu Depart",
                                                            cell,
                                                            "text", lieu_depart,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 5eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date Arrivee",
                                                            cell,
                                                            "text", date_arrive,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 6eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Lieu Arrivee",
                                                            cell,
                                                            "text", lieu_arrive,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        /* Creation de la 7eme colonne */
        cell= gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Aeroport",
                                                            cell,
                                                            "text", aeroport,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);





       gtk_tree_view_set_model ( GTK_TREE_VIEW (liste),
                                  GTK_TREE_MODEL(store)  );







}

void afficher_vols_reserve(GtkWidget *liste)
{
  enum {
          numero,date_depart,lieu_depart,date_arrive,lieu_arrive,aeroport

  };
GtkListStore *store=NULL;
GtkTreeViewColumn *column;
GtkCellRenderer *cell;
FILE *f;



/* Creation du modele */
        store = gtk_list_store_new(6,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
/* Insertion des elements */
      f=fopen("vols_res.txt","a+");
        while(fscanf(f,"%s %s %s %s %s %s\n",v.numero,v.date_depart,v.lieu_depart,v.date_arrive,v.lieu_arrive,v.aeroport)!=EOF)
        {GtkTreeIter pIter;
  /* Creation de la nouvelle ligne */
        gtk_list_store_append(store, &pIter);
  /* Mise a jour des donnees */
        gtk_list_store_set(store, &pIter,

                           numero,v.numero,
                           date_depart,v.date_depart,
                           lieu_depart,v.lieu_depart,
                           date_arrive,v.date_arrive,
                           lieu_arrive,v.lieu_arrive,
                           aeroport,v.aeroport,
                            -1);}
        fclose(f);


  /* Creation de la 2eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(0));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Numero Vol",
                                                            cell,
                                                            "text", numero,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

  /* Creation de la 3eme colonne */
        cell = gtk_cell_renderer_text_new();
          g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
          g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(1));
           g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Date Depart",
                                                            cell,
                                                            "text", date_depart,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 4eme colonne */
        cell = gtk_cell_renderer_text_new();
          g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
          g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(2));
           g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Lieu Depart",
                                                            cell,
                                                            "text", lieu_depart,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 5eme colonne */
        cell = gtk_cell_renderer_text_new();
          g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
          g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(3));
           g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Date Arrivee",
                                                            cell,
                                                            "text", date_arrive,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 6eme colonne */
        cell = gtk_cell_renderer_text_new();
          g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
          g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(4));
           g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Lieu Arrivee",
                                                            cell,
                                                            "text", lieu_arrive,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        /* Creation de la 7eme colonne */
        cell= gtk_cell_renderer_text_new();
          g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
          g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(5));
           g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Aeroport",
                                                            cell,
                                                            "text", aeroport,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);





       gtk_tree_view_set_model ( GTK_TREE_VIEW (liste),
                                  GTK_TREE_MODEL(store)  );







}
void cell_edited (GtkCellRendererText *renderer,gchar *path, gchar* newtext, GtkListStore *store)
{
GtkTreeIter iter;
int x= GPOINTER_TO_UINT(g_object_get_data(G_OBJECT(renderer),"num"));
gtk_tree_model_get_iter_from_string(GTK_TREE_MODEL(store),&iter,path);
gtk_list_store_set(GTK_LIST_STORE(store),&iter,x,newtext,-1);
gtk_widget_show(lookup_widget(panier,"modifier_vol"));
gtk_widget_show(lookup_widget(panier,"modifier_hebergement"));
gtk_widget_show(lookup_widget(panier,"modifier_excursion"));
gtk_widget_show(lookup_widget(panier,"modifier_location"));
}
void afficher_excursions(GtkWidget *liste)
{
  enum {
          numero,date_depart,date_arrive,lieu_depart,lieu_arrive,prix,programme

  };
GtkListStore *store=NULL;
GtkTreeViewColumn *column;
GtkCellRenderer *cell;
FILE *f;
excursion e;


/* Creation du modele */
        store = gtk_list_store_new(7,G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
/* Insertion des elements */
      f=fopen("excursion.txt","a+");
        while(fscanf(f,"%s %s %s %s %s %s %s\n",e.numero,e.date_depart,e.date_arrive,e.lieu_depart,e.lieu_arrive,e.prix,e.programme)!=EOF)
        {GtkTreeIter pIter;
  /* Creation de la nouvelle ligne */
        gtk_list_store_append(store, &pIter);
  /* Mise a jour des donnees */
        gtk_list_store_set(store, &pIter,

                           numero,e.numero,
                           date_depart,e.date_depart,
                           date_arrive,e.date_arrive,
                           lieu_depart,e.lieu_depart,
                           lieu_arrive,e.lieu_arrive,
                           prix,e.prix,
                           programme,e.programme,
                            -1);}
        fclose(f);


  /* Creation de la 2eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Numero Excursion",
                                                            cell,
                                                            "text", numero,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

  /* Creation de la 3eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date Depart",
                                                            cell,
                                                            "text", date_depart,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 4eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date Arrivee",
                                                            cell,
                                                            "text", date_arrive,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 5eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Lieu Depart",
                                                            cell,
                                                            "text", lieu_depart,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 6eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Lieu Arrivee",
                                                            cell,
                                                            "text", lieu_arrive,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        /* Creation de la 7eme colonne */
        cell= gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Prix",
                                                            cell,
                                                            "text", prix,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


        cell= gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Programme",
                                                            cell,
                                                            "text", programme,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


       gtk_tree_view_set_model ( GTK_TREE_VIEW (liste),
                                  GTK_TREE_MODEL(store)  );







}
void afficher_excursions_reserve(GtkWidget *liste)
{
  enum {
          numero,date_depart,date_arrive,lieu_depart,lieu_arrive,prix,programme

  };
GtkListStore *store=NULL;
GtkTreeViewColumn *column;
GtkCellRenderer *cell;
FILE *f;
excursion e;


/* Creation du modele */
        store = gtk_list_store_new(7,G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
/* Insertion des elements */
      f=fopen("excursion_reserve.txt","a+");
        while(fscanf(f,"%s %s %s %s %s %s %s\n",e.numero,e.date_depart,e.date_arrive,e.lieu_depart,e.lieu_arrive,e.prix,e.programme)!=EOF)
        {GtkTreeIter pIter;
  /* Creation de la nouvelle ligne */
        gtk_list_store_append(store, &pIter);
  /* Mise a jour des donnees */
        gtk_list_store_set(store, &pIter,

                           numero,e.numero,
                           date_depart,e.date_depart,
                           date_arrive,e.date_arrive,
                           lieu_depart,e.lieu_depart,
                           lieu_arrive,e.lieu_arrive,
                           prix,e.prix,
                           programme,e.programme,
                            -1);}
        fclose(f);


  /* Creation de la 2eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(0));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Numero Excursion",
                                                            cell,
                                                            "text", numero,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

  /* Creation de la 3eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(1));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Date Depart",
                                                            cell,
                                                            "text", date_depart,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 4eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(2));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Date Arrivee",
                                                            cell,
                                                            "text", date_arrive,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 5eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(3));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Lieu Depart",
                                                            cell,
                                                            "text", lieu_depart,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 6eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(4));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Lieu Arrivee",
                                                            cell,
                                                            "text", lieu_arrive,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        /* Creation de la 7eme colonne */
        cell= gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(5));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Prix",
                                                            cell,
                                                            "text", prix,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


        cell= gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(6));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Programme",
                                                            cell,
                                                            "text", programme,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


       gtk_tree_view_set_model ( GTK_TREE_VIEW (liste),
                                  GTK_TREE_MODEL(store)  );







}
void afficher_locations(GtkWidget *liste)
{
  enum {
          numero,debut_location,lieu,fin_location,marque,prix

  };
GtkListStore *store=NULL;
GtkTreeViewColumn *column;
GtkCellRenderer *cell;
FILE *f;
location l;


/* Creation du modele */
        store = gtk_list_store_new(5,G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
/* Insertion des elements */
      f=fopen("locations.txt","a+");
        while(fscanf(f,"%s %s %s %s %s %s\n",l.numero,l.debut_location,l.lieu,l.fin_location,l.marque,l.prix)!=EOF)
        {GtkTreeIter pIter;
  /* Creation de la nouvelle ligne */
        gtk_list_store_append(store, &pIter);
  /* Mise a jour des donnees */
        gtk_list_store_set(store, &pIter,

                           numero,l.numero,
                           debut_location,l.debut_location,
                           lieu,l.lieu,
                           fin_location,l.fin_location,
                           marque,l.marque,
                           prix,l.prix,
                            -1);}
        fclose(f);


  /* Creation de la 2eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Numero Voiture",
                                                            cell,
                                                            "text", numero,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

  /* Creation de la 3eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date debut location",
                                                            cell,
                                                            "text", debut_location,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 4eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Lieu",
                                                            cell,
                                                            "text", lieu,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 5eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Fin location",
                                                            cell,
                                                            "text",  fin_location,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 6eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Marque",
                                                            cell,
                                                            "text", marque,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        /* Creation de la 7eme colonne */
        cell= gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Prix",
                                                            cell,
                                                            "text", prix,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);



       gtk_tree_view_set_model ( GTK_TREE_VIEW (liste),
                                  GTK_TREE_MODEL(store)  );







}

void afficher_locations_reserve(GtkWidget *liste)
{
  enum {
          numero,debut_location,lieu,fin_location,marque,prix

  };
GtkListStore *store=NULL;
GtkTreeViewColumn *column;
GtkCellRenderer *cell;
FILE *f;
location l;


/* Creation du modele */
        store = gtk_list_store_new(5,G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
/* Insertion des elements */
      f=fopen("locations_reserve.txt","a+");
        while(fscanf(f,"%s %s %s %s %s %s\n",l.numero,l.debut_location,l.lieu,l.fin_location,l.marque,l.prix)!=EOF)
        {GtkTreeIter pIter;
  /* Creation de la nouvelle ligne */
        gtk_list_store_append(store, &pIter);
  /* Mise a jour des donnees */
        gtk_list_store_set(store, &pIter,

                           numero,l.numero,
                           debut_location,l.debut_location,
                           lieu,l.lieu,
                           fin_location,l.fin_location,
                           marque,l.marque,
                           prix,l.prix,
                            -1);}
        fclose(f);


  /* Creation de la 2eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(0));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Numero Voiture",
                                                            cell,
                                                            "text", numero,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

  /* Creation de la 3eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(1));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Date debut location",
                                                            cell,
                                                            "text", debut_location,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 4eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(2));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Lieu",
                                                            cell,
                                                            "text", lieu,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 5eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(3));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Fin location",
                                                            cell,
                                                            "text",  fin_location,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 6eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(4));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Marque",
                                                            cell,
                                                            "text", marque,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        /* Creation de la 7eme colonne */
        cell= gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(5));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Prix",
                                                            cell,
                                                            "text", prix,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);



       gtk_tree_view_set_model ( GTK_TREE_VIEW (liste),
                                  GTK_TREE_MODEL(store)  );







}


void afficher_heb(GtkWidget *liste)
{
  enum {
          numero,date_depart,date_arrive,nombre_chambres,nombre_chambres_double,prix

  };
GtkListStore *store=NULL;
GtkTreeViewColumn *column;
GtkCellRenderer *cell;
FILE *f;
hebergements h;



/* Creation du modele */
        store = gtk_list_store_new(6,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
/* Insertion des elements */
      f=fopen("hebergements.txt","a+");
        while(fscanf(f,"%s %s %s %s %s %s\n",h.numero,h.date_depart,h.date_arrive,h.nombre_chambres,h.nombre_chambres_double,h.prix)!=EOF)
        {GtkTreeIter pIter;
  /* Creation de la nouvelle ligne */
        gtk_list_store_append(store, &pIter);
  /* Mise a jour des donnees */
        gtk_list_store_set(store, &pIter,

                          numero, h.numero,
                          date_depart, h.date_depart,
                          date_arrive, h.date_arrive,
                           nombre_chambres,h.nombre_chambres,
                           nombre_chambres_double,h.nombre_chambres_double,
                           prix,h.prix,
                            -1);}
        fclose(f);

  /* Creation de la 1ere colonne */


  /* Creation de la 2eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Numero Hotel",
                                                            cell,
                                                            "text", numero,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

  /* Creation de la 3eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date Depart",
                                                            cell,
                                                            "text", date_depart,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 4eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date Arrivee",
                                                            cell,
                                                            "text", date_arrive,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 5eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nombre de Chambres",
                                                            cell,
                                                            "text", nombre_chambres,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 6eme colonne */
        cell = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nombre de Chambres double",
                                                            cell,
                                                            "text", nombre_chambres_double,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        /* Creation de la 7eme colonne */
        cell= gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Prix",
                                                            cell,
                                                            "text", prix,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);





       gtk_tree_view_set_model ( GTK_TREE_VIEW (liste),
                                  GTK_TREE_MODEL(store)  );





}
void afficher_heb_reserve(GtkWidget *liste)
{
  enum {
          numero,date_depart,date_arrive,nombre_chambres,nombre_chambres_double,prix

  };
GtkListStore *store=NULL;
GtkTreeViewColumn *column;
GtkCellRenderer *cell;
FILE *f;
hebergements h;


/* Creation du modele */
        store = gtk_list_store_new(6,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING);
/* Insertion des elements */
      f=fopen("hebergements_res.txt","a+");
        while(fscanf(f,"%s %s %s %s %s %s\n",h.numero,h.date_depart,h.date_arrive,h.nombre_chambres,h.nombre_chambres_double,h.prix)!=EOF)
        {GtkTreeIter pIter;
  /* Creation de la nouvelle ligne */
        gtk_list_store_append(store, &pIter);
  /* Mise a jour des donnees */
        gtk_list_store_set(store, &pIter,

                          numero, h.numero,
                          date_depart, h.date_depart,
                          date_arrive, h.date_arrive,
                           nombre_chambres,h.nombre_chambres,
                           nombre_chambres_double,h.nombre_chambres_double,
                           prix,h.prix,
                            -1);}
        fclose(f);

  /* Creation de la 1ere colonne */


  /* Creation de la 2eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(0));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Numero Hotel",
                                                            cell,
                                                            "text", numero,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

  /* Creation de la 3eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(1));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Date Depart",
                                                            cell,
                                                            "text", date_depart,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 4eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(2));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Date Arrivee",
                                                            cell,
                                                            "text", date_arrive,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 5eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(3));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Nombre de Chambres",
                                                            cell,
                                                            "text", nombre_chambres,
                                                            NULL);

  /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
  /* Creation de la 6eme colonne */
        cell = gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(4));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Nombre de Chambres double",
                                                            cell,
                                                            "text", nombre_chambres_double,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        /* Creation de la 7eme colonne */
        cell= gtk_cell_renderer_text_new();
        g_object_set(cell,"editable",TRUE,"editable-set",TRUE,NULL);
        g_object_set_data(G_OBJECT(cell),"num",GUINT_TO_POINTER(5));
       g_signal_connect (G_OBJECT(cell),"edited",G_CALLBACK(cell_edited),store);
        column = gtk_tree_view_column_new_with_attributes("Prix",
                                                            cell,
                                                            "text", prix,
                                                            NULL);

        /* Ajout de la colonne à la vue */
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);





       gtk_tree_view_set_model ( GTK_TREE_VIEW (liste),
                                  GTK_TREE_MODEL(store)  );





}
