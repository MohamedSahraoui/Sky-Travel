#include<gtk/gtk.h>

typedef struct
{
char nom[20];
char prenom[30];
char cin[20];
char mail[30];
char adresse[10];
char datenaissance[30];
char sexe[10];

}Agent;
void ajouter_agent(Agent A);
void afficher_agent(GtkWidget *liste);
//int verifier_ciin(char id[]);
int verifier_id(char ID[]);
void modifier_agent(Agent A);
void supprimer_agent(char refer[]);
