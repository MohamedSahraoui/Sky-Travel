#include<stdio.h>
#include<string.h>
#include"agent.h"
#include <gtk/gtk.h>

enum
{
	CIN,
	NOM,
	PRENOM,
	DATENAISSANCE,
	ADRESSE,
        MAIL,
        SEXE,
	COLUMNS
};

void ajouter_agent(Agent A)
{
FILE *f;
f=fopen("utilisateur.txt","a+");
if (f!=NULL)
{ fprintf(f,"%s %s %s %s %s %s %s \n",A.nom,A.prenom,A.cin,A.mail,A.adresse,A.datenaissance,A.sexe);
fclose(f);
}}
//void afficher_agent(GtkWidget *liste)
//{
//GtkCellRenderer *renderer ;
//GtkTreeViewColumn *column;
//GtkTreeIter iter;
//GtkListStore *store;
//char nom[30];
//char prenom[30];
//char cin[30];
//char mail[30];
//char adresse[30];
//char datenaissance[30];
//char sexe[30];
//store=NULL ;
//FILE*f;
//store=gtk_tree_view_get_model(liste);
//if (store==NULL)
//{
//renderer = gtk_cell_renderer_text_new ();
//column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
//gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

//renderer = gtk_cell_renderer_text_new ();
//column = gtk_tree_view_column_new_with_attributes/("prenom",renderer,"text",PRENOM,NULL);
//gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

//renderer = gtk_cell_renderer_text_new ();
//column = gtk_tree_view_column_new_with_attributes//("cin",renderer,"text",CIN,NULL);
//gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

//renderer = gtk_cell_renderer_text_new ();
//column = gtk_tree_view_column_new_with_attributes("mail",renderer,"text",MAIL,NULL);
//gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

//renderer = gtk_cell_renderer_text_new ();
//column = gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",ADRESSE,NULL);
//gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
//renderer = gtk_cell_renderer_text_new ();
//column = gtk_tree_view_column_new_with_attributes("datenaissance",renderer,"text",DATENAISSANCE,NULL);
//gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
//renderer = gtk_cell_renderer_text_new ();
//column = gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
//gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


//store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
//f = fopen("utilisateur.txt","r");
//if (f==NULL)
//{ return; }
//else 
//{ f= fopen("utilisateur.txt","a+");
	//while (fscanf(f,"%s %s %s %s %s %s %s \n",nom,prenom,cin,mail,adresse,datenaissance,sexe)!=EOF)
  //{ 	gtk_list_store_append(store, &iter);
	//gtk_list_store_set(store,&iter, NOM, nom, PRENOM, prenom, CIN, cin, MAIL, mail, ADRESSE, adresse,DATENAISSANCE,datenaissance,SEXE,sexe -1);
  //}

//fclose(f);
//gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
//g_object_unref (store);
//}
//}}
void afficher_agent(GtkWidget *window2)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;

	GtkListStore *store;

char nom [30];
char prenom [30];
char cin [30];
char mail[30];
char adresse[30];
char datenaissance[30];
char sexe[30];
store=NULL;

FILE *f;

store=gtk_tree_view_get_model(window2);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" nom",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (window2),column);
	
renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" prenom",renderer, "text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (window2),column);
	
renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (window2),column);
	
renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" mail",renderer, "text",MAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (window2),column);
	
renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" adresse",renderer,"text",ADRESSE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (window2),column);
	renderer = gtk_cell_renderer_text_new();
gtk_tree_view_append_column (GTK_TREE_VIEW (window2),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" datenaissance",renderer, "text",DATENAISSANCE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (window2),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" sexe",renderer, "text",SEXE,NULL);
}
	store=gtk_list_store_new(7,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("utilisateur.txt","r");
if(f==NULL)
{
return;
}
else
{
 f=fopen("utilisateur.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s %s\n",nom,prenom,cin,mail,adresse,datenaissance,sexe)!=EOF)
	{
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,CIN,cin,MAIL,mail,ADRESSE,adresse,DATENAISSANCE,datenaissance,SEXE,sexe-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(window2), GTK_TREE_MODEL(store));
	g_object_unref(store);}

	
}
int verifier_id(char ID[])
{Agent A;
FILE *f;
int test = 0 ; 
f=fopen("utilisateur.txt","r");
if(f!=NULL) { 
while(fscanf(f,"%s %s %s %s %s %s %s\n",A.nom,A.prenom,A.cin,A.mail,A.adresse,A.datenaissance,A.sexe)!=EOF) 
{ 
if((strcmp(A.cin,ID)==0))
test=1 ;
 } }
fclose(f);
 
return test;
}

void modifier_agent(Agent a)
{
Agent m;
//Agent A;
FILE *f;
FILE *f2;
f=fopen("utilisateur.txt","r");
f2=fopen("utilisateur_tmp.txt","a+"); 
if (f!=NULL)
{
if (f2!=NULL)

{ 
     while (fscanf(f,"%s %s %s %s %s %s %s\n",m.nom,m.prenom,m.cin,m.mail,m.adresse,m.datenaissance,m.sexe)!=EOF)
    { 
	if (strcmp(a.cin,m.cin)==0){
   fprintf(f2,"%s %s %s %s %s %s %s\n",a.nom,a.prenom,a.cin,a.mail,a.adresse,a.datenaissance,a.sexe);
}
	else 	
{	    fprintf(f2,"%s %s %s %s %s %s %s\n",m.nom,m.prenom,m.cin,m.mail,m.adresse,m.datenaissance,m.sexe);
     }

}}
fclose(f2);
fclose(f);
remove("utilisateur.txt");
rename("utilisateur_tmp.txt","utilisateur.txt");

}}
void supprimer_agent(char refer[])
{
FILE *f,*f1;
Agent A;
 
f=fopen("utilisateur.txt","r"); 
f1=fopen("utilisateur_tmp.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s %s %s\n",A.nom,A.prenom,A.cin,A.mail,A.adresse,A.datenaissance,A.sexe)!=EOF) 
{
if(strcmp(refer,A.cin)!=0)
{
fprintf(f1,"%s %s %s %s %s %s %s\n",A.nom,A.prenom,A.cin,A.mail,A.adresse,A.datenaissance,A.sexe);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("utilisateur.txt","w"); 
f1=fopen("utilisateur_tmp.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s %s %s\n",A.nom,A.prenom,A.cin,A.mail,A.adresse,A.datenaissance,A.sexe)!=EOF) 
{
if(strcmp(refer,A.cin)!=0)
{
fprintf(f,"%s %s %s %s %s %s %s\n",A.nom,A.prenom,A.cin,A.mail,A.adresse,A.datenaissance,A.sexe);
}}
fclose(f) ; 
fclose(f1);
}}
