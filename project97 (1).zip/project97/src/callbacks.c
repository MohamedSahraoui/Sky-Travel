#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "agent.h"
//#include "destination.h"


void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window3;
	window1=lookup_widget(objet,"window1");	
	window3 = create_window3();
	gtk_widget_destroy(window1);
	gtk_widget_show(window3);
}


void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
Agent A;
GtkWidget *entry1;
	GtkWidget *entry2;
	GtkWidget *entry3;
	GtkWidget *entry4;
        GtkWidget *entry5;
	GtkWidget *entry6;
	GtkWidget *entry7;
	GtkWidget *window1;
  	//GtkWidget *window9;

	window1=lookup_widget(objet,"window1");	
	entry1=lookup_widget(objet, "entry1");
	entry2=lookup_widget(objet, "entry2");
	entry3=lookup_widget(objet, "entry3");
	entry4=lookup_widget(objet, "entry4");
        entry5=lookup_widget(objet, "entry5");
	entry6=lookup_widget(objet, "entry6");
	entry7=lookup_widget(objet, "entry7");


	strcpy(A.nom,gtk_entry_get_text(GTK_ENTRY(entry1)));
	strcpy(A.prenom,gtk_entry_get_text(GTK_ENTRY(entry2)));
	strcpy(A.cin,gtk_entry_get_text(GTK_ENTRY(entry3)));
	strcpy(A.mail,gtk_entry_get_text(GTK_ENTRY(entry4)));
	strcpy(A.adresse,gtk_entry_get_text(GTK_ENTRY(entry5)));
	strcpy(A.datenaissance,gtk_entry_get_text(GTK_ENTRY(entry6)));
	strcpy(A.sexe,gtk_entry_get_text(GTK_ENTRY(entry7)));
        ajouter_agent(A);
}


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
Agent A;
GtkWidget *treeview1;
//GtkWidget *window2;

//window2=lookup_widget(objet,"window2");	
		//window1= create_window1();
		//gtk_widget_destroy(window1);
//gtk_widget_show(window2);
treeview1=lookup_widget(objet,"treeview1");
afficher_agent(treeview1);
}


void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window2;
		GtkWidget *window5;
		window2=lookup_widget(objet,"window2");	
		window5 = create_window5();
		gtk_widget_destroy(window2);
		gtk_widget_show(window5);
}


void
on_button6_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window2;
	GtkWidget *window4;
	window2=lookup_widget(objet,"window2");	
	window4 = create_window4();
	gtk_widget_destroy(window2);
	gtk_widget_show(window4);
}


void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window2;
	window2=lookup_widget(objet,"window2");	
	window1 = create_window1();
	gtk_widget_destroy(window2);
	gtk_widget_show(window1);
}


void
on_button7_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window2;
	GtkWidget *window3;
	window3=lookup_widget(objet,"window3");	
	window2 = create_window2();
	gtk_widget_destroy(window3);
	gtk_widget_show(window2);
}


void
on_button8_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window3;
	window3=lookup_widget(objet,"window3");	
	window1 = create_window1();
	gtk_widget_destroy(window3);
	gtk_widget_show(window1);
}


void
on_button9_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window2;
	GtkWidget *window4;
	window4=lookup_widget(objet,"window4");	
	window2 = create_window2();
	gtk_widget_destroy(window4);
	gtk_widget_show(window2);
}


void
on_button10_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
//GtkWidget *window4;
  	//GtkWidget *entry8;

	//window4=lookup_widget(objet,"window4");	
	//entry8=lookup_widget(objet, "entry8");
GtkWidget *entry20;
GtkWidget *output17;
Agent A;
char refer[20];
entry20=lookup_widget(objet,"entry8");
output17=lookup_widget(objet,"label26");
strcpy(refer,gtk_entry_get_text(GTK_ENTRY(entry20)));
if(verifier_id(refer)==0)
gtk_label_set_text(GTK_LABEL(output17),"agent inexistante");
else
{
supprimer_agent(refer);
gtk_label_set_text(GTK_LABEL(output17),"agent supprimé");
}
	
}


void
on_button11_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window2;
		GtkWidget *window5;
		window5=lookup_widget(objet,"window5");	
		window2 = create_window2();
		gtk_widget_destroy(window5);
		gtk_widget_show(window2);
}


void
on_button12_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

		   //window5=lookup_widget(objet,"window5");	
		  // entry9=lookup_widget(objet, "entry9");
		   //label26=lookup_widget(objet, "label13");
                  // window6 = create_window6();
		  // gtk_widget_destroy(window5);
char ID[20];
int test;
Agent A;
GtkWidget *entry1,*entry10,*entry11,*entry12,*entry13,*entry14,*entry15, *entry16;
GtkWidget *window5,*window6;
GtkWidget *output;
window6=create_window6();
entry1=lookup_widget(objet,"entry9");
entry10=lookup_widget(window6,"entry10");
entry11=lookup_widget(window6,"entry11");
entry12=lookup_widget(window6,"entry12");
entry13=lookup_widget(window6,"entry13");
entry14=lookup_widget(window6,"entry14");
entry15=lookup_widget(window6,"entry15");
entry16=lookup_widget(window6,"entry16");

output= lookup_widget(objet,"label24");
strcpy(ID,gtk_entry_get_text(GTK_ENTRY(entry1)));
if (verifier_id(ID)==0)
gtk_label_set_text(GTK_LABEL(output),"agent n'existe pas");
else
{
FILE *f2;
f2=fopen("utilisateur.txt","r"); 
if (f2!=NULL)
{while (fscanf(f2,"%s %s %s %s %s %s %s \n",A.nom,A.prenom,A.cin,A.mail,A.adresse,A.datenaissance,A.sexe)!=EOF)
{if (strcmp(A.cin,ID)==0) 
{ gtk_widget_show(window6);
gtk_entry_set_text(GTK_ENTRY(entry10),A.nom) ;
gtk_entry_set_text(GTK_ENTRY(entry11),A.prenom) ;
gtk_entry_set_text(GTK_ENTRY(entry12),A.cin) ;
gtk_entry_set_text(GTK_ENTRY(entry13),A.mail) ;
gtk_entry_set_text(GTK_ENTRY(entry14),A.adresse) ;
gtk_entry_set_text(GTK_ENTRY(entry15),A.datenaissance) ;
gtk_entry_set_text(GTK_ENTRY(entry16),A.sexe) ;
break ;}}
}
fclose(f2);
}		// gtk_widget_show(window6);
}
	   
		 

void
on_button13_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{ 
//Agent A;
//GtkWidget *entry10,*entry11,*entry12,*entry13,*entry14,*entry15,*entry16;//*entry9;
//GtkWidget *output;
//GtkWidget *window6;
//GtkWidget *window5;
//window5=lookup_widget(objet,"window5");	
//window6 = create_window6();
//gtk_widget_destroy(window5);
//gtk_widget_show(window6);
Agent a;
GtkWidget *entry10,*entry11,*entry12,*entry13,*entry14,*entry15,*entry16;
GtkWidget *output;
entry10=lookup_widget(objet,"entry10");
entry11=lookup_widget(objet,"entry11");
entry12=lookup_widget(objet,"entry12");
entry13=lookup_widget(objet,"entry13");
entry14=lookup_widget(objet,"entry14");
entry15=lookup_widget(objet,"entry15");
entry16=lookup_widget(objet,"entry16");
output=lookup_widget(objet,"label23");
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(entry10)));
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(entry11)));
strcpy(a.cin,gtk_entry_get_text(GTK_ENTRY(entry12)));
strcpy(a.mail,gtk_entry_get_text(GTK_ENTRY(entry13)));
strcpy(a.adresse,gtk_entry_get_text(GTK_ENTRY(entry14)));
strcpy(a.datenaissance,gtk_entry_get_text(GTK_ENTRY(entry15)));
strcpy(a.sexe,gtk_entry_get_text(GTK_ENTRY(entry16)));

modifier_agent(a);
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés") ;
}

